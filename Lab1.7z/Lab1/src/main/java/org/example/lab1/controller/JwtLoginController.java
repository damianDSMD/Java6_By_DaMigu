package org.example.lab1.controller;

public class JwtLoginController {
}

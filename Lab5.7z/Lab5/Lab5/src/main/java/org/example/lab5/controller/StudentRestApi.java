package org.example.lab5.controller;

public class StudentRestApi {
}

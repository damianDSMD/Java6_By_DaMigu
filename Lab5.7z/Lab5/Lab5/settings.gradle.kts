rootProject.name = "Lab5"
